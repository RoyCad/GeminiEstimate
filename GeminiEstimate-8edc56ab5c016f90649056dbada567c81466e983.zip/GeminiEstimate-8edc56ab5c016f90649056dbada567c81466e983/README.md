# GeminiEstimate

This is a NextJS starter in Firebase Studio.

The project's GitHub repository can be found here: https://github.com/RoyCad/GeminiEstimate.git
# GeminiEstimate

