# GeminiEstimate

This is a NextJS starter in Firebase Studio.

The project's GitHub repository can be found here: https://github.com/RoyCad/GeminiEstimate.git

To get started, take a look at src/app/page.tsx.
