'use client';
import ProfileSettingsPage from "./profile/page";

export default function SettingsPage() {
    return <ProfileSettingsPage />;
}
