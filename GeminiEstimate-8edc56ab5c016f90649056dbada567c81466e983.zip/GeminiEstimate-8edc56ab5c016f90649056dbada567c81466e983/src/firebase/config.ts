export const firebaseConfig = {
  "projectId": "studio-7142193152-eba66",
  "appId": "1:676397765815:web:0af2431498672cba472932",
  "apiKey": "AIzaSyDe_MZLA_i6F4aOlOhf9Evkw3tOn7Y6amQ",
  "authDomain": "studio-7142193152-eba66.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "676397765815"
};
